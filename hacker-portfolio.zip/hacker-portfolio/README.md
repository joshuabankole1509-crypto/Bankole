# Hacker Portfolio — Deployment Guide

## 🚀 How to Deploy on Vercel (Free)

### Step 1 — Install Node.js
Download and install from: https://nodejs.org (click the LTS version)

---

### Step 2 — Test locally (optional but recommended)
Open your terminal / command prompt and run:

```bash
cd hacker-portfolio
npm install
npm run dev
```
Then open http://localhost:3000 in your browser to preview it.

---

### Step 3 — Create a GitHub account
Go to https://github.com and sign up for free.

---

### Step 4 — Upload your project to GitHub
1. Go to https://github.com/new
2. Name it `hacker-portfolio`
3. Click **Create repository**
4. Upload all your files (drag and drop the folder)

---

### Step 5 — Deploy on Vercel
1. Go to https://vercel.com and sign up with your GitHub account
2. Click **"Add New Project"**
3. Select your `hacker-portfolio` repo
4. Click **Deploy**

✅ Done! You'll get a free link like: `hacker-portfolio.vercel.app`

---

## 📁 Project Structure
```
hacker-portfolio/
├── app/
│   ├── layout.js       ← Page title & meta info
│   ├── page.js         ← Entry point
│   └── Portfolio.js    ← Your full portfolio (edit this!)
├── package.json
├── next.config.js
└── README.md
```

## ✏️ How to update your portfolio
Edit `app/Portfolio.js` — all your content (name, projects, links) is in that file.
After editing, push to GitHub and Vercel will auto-redeploy.
