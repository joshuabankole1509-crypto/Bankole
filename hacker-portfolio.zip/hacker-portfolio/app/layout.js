export const metadata = {
  title: "Hacker — Web Designer & Brand Builder",
  description: "Web Designer based in Lagos. I help local businesses attract more customers through clean, modern websites.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, padding: 0, background: "#060608" }}>
        {children}
      </body>
    </html>
  );
}
