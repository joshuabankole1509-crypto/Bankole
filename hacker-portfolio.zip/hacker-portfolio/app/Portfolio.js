"use client";

import { useState, useEffect, useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";

const NAV_LINKS = ["About", "Skills", "Projects", "Contact"];

const SKILLS = [
  {
    icon: "⬡",
    title: "Web Design",
    desc: "Modern UI/UX websites that convert visitors into customers.",
    tag: "UI/UX",
  },
  {
    icon: "◈",
    title: "Business Branding",
    desc: "Helping small businesses look polished, premium, and professional.",
    tag: "Brand",
  },
  {
    icon: "⬢",
    title: "Lead Systems",
    desc: "WhatsApp ordering flows and contact funnels built to close.",
    tag: "Growth",
  },
];

const PROJECTS = [
  {
    id: "01",
    title: "Fammis Place",
    subtitle: "Restaurant Concept",
    desc: "A modern, mobile-first restaurant website redesign for a LASU food business — clean menus, WhatsApp ordering, and a brand identity that stands out.",
    tags: ["Web Design", "Branding", "UI"],
    color: "#FF6B35",
  },
  {
    id: "02",
    title: "Foodlum",
    subtitle: "Student Food Platform",
    desc: "Student-focused food delivery and ordering system UI — designed for speed, trust, and campus-culture aesthetic.",
    tags: ["Product UI", "System Design", "Brand"],
    color: "#00D4AA",
  },
];

const ACHIEVEMENTS = [
  { num: "5+", label: "Demo sites built for Lagos businesses" },
  { num: "2+", label: "UI concepts designed for LASU vendors" },
  { num: "100%", label: "Mobile-first, responsive layouts" },
  { num: "∞", label: "Passion for clean, converting design" },
];

export default function Portfolio() {
  const [cursorPos, setCursorPos] = useState({ x: -100, y: -100 });
  const heroRef = useRef(null);
  const { scrollY } = useScroll();
  const heroOpacity = useTransform(scrollY, [0, 400], [1, 0]);
  const heroY = useTransform(scrollY, [0, 400], [0, -60]);

  useEffect(() => {
    const move = (e) => setCursorPos({ x: e.clientX, y: e.clientY });
    window.addEventListener("mousemove", move);
    return () => window.removeEventListener("mousemove", move);
  }, []);

  const stagger = {
    hidden: {},
    show: { transition: { staggerChildren: 0.12 } },
  };
  const fadeUp = {
    hidden: { opacity: 0, y: 32 },
    show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.25, 0.1, 0.25, 1] } },
  };

  return (
    <div
      style={{
        background: "#060608",
        minHeight: "100vh",
        color: "#E8E4DC",
        fontFamily: "'DM Sans', sans-serif",
        overflowX: "hidden",
        position: "relative",
      }}
    >
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:ital,wght@0,300;0,400;0,500;1,300&family=Bebas+Neue&display=swap');

        * { box-sizing: border-box; margin: 0; padding: 0; }

        ::-webkit-scrollbar { width: 3px; }
        ::-webkit-scrollbar-track { background: #060608; }
        ::-webkit-scrollbar-thumb { background: #FF6B35; border-radius: 2px; }

        .glow-text { text-shadow: 0 0 60px rgba(255, 107, 53, 0.4); }

        .nav-link {
          position: relative;
          font-size: 13px;
          letter-spacing: 0.12em;
          text-transform: uppercase;
          color: #888;
          text-decoration: none;
          transition: color 0.3s;
        }
        .nav-link:hover { color: #E8E4DC; }
        .nav-link::after {
          content: '';
          position: absolute;
          bottom: -2px; left: 0;
          width: 0; height: 1px;
          background: #FF6B35;
          transition: width 0.3s ease;
        }
        .nav-link:hover::after { width: 100%; }

        .skill-card {
          border: 1px solid rgba(255,255,255,0.06);
          background: rgba(255,255,255,0.025);
          backdrop-filter: blur(12px);
          border-radius: 2px;
          padding: 32px;
          position: relative;
          overflow: hidden;
          cursor: default;
          transition: border-color 0.3s, background 0.3s;
          height: 100%;
        }
        .skill-card:hover {
          border-color: rgba(255, 107, 53, 0.35);
          background: rgba(255, 107, 53, 0.04);
        }
        .skill-card::before {
          content: '';
          position: absolute;
          top: 0; left: 0;
          width: 2px; height: 0;
          background: #FF6B35;
          transition: height 0.4s ease;
        }
        .skill-card:hover::before { height: 100%; }

        .project-card {
          border: 1px solid rgba(255,255,255,0.06);
          background: rgba(255,255,255,0.02);
          border-radius: 2px;
          padding: 40px;
          position: relative;
          overflow: hidden;
          transition: border-color 0.3s;
          height: 100%;
        }
        .project-card:hover { border-color: rgba(255,255,255,0.15); }

        .btn-primary {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          background: #FF6B35;
          color: #060608;
          font-family: 'DM Sans', sans-serif;
          font-size: 13px;
          font-weight: 500;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          border: none;
          padding: 14px 28px;
          cursor: pointer;
          transition: background 0.2s, transform 0.2s;
          border-radius: 1px;
          text-decoration: none;
        }
        .btn-primary:hover { background: #ff8255; transform: translateY(-1px); }

        .btn-ghost {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          background: transparent;
          color: #E8E4DC;
          font-family: 'DM Sans', sans-serif;
          font-size: 13px;
          font-weight: 400;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          border: 1px solid rgba(255,255,255,0.18);
          padding: 14px 28px;
          cursor: pointer;
          transition: border-color 0.2s, transform 0.2s;
          border-radius: 1px;
          text-decoration: none;
        }
        .btn-ghost:hover { border-color: rgba(255,255,255,0.5); transform: translateY(-1px); }

        .section-label {
          font-size: 11px;
          letter-spacing: 0.25em;
          text-transform: uppercase;
          color: #FF6B35;
          margin-bottom: 16px;
          display: flex;
          align-items: center;
          gap: 12px;
        }
        .section-label::before {
          content: '';
          width: 24px; height: 1px;
          background: #FF6B35;
        }

        .stat-num {
          font-family: 'Bebas Neue', cursive;
          font-size: clamp(36px, 5vw, 52px);
          color: #FF6B35;
          line-height: 1;
        }

        .noise-overlay {
          position: fixed;
          inset: 0;
          opacity: 0.03;
          pointer-events: none;
          z-index: 999;
          background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
          background-size: 200px;
        }

        @media (max-width: 768px) {
          .nav-links { display: none !important; }
          .grid-3 { grid-template-columns: 1fr !important; }
          .grid-2 { grid-template-columns: 1fr !important; }
          .grid-4 { grid-template-columns: 1fr 1fr !important; }
          .hero-pad { padding: 100px 24px 80px !important; }
          .section-pad { padding: 60px 24px !important; }
          .nav-pad { padding: 16px 24px !important; }
          .footer-pad { padding: 24px !important; flex-direction: column !important; gap: 8px !important; }
        }
      `}</style>

      {/* Noise overlay */}
      <div className="noise-overlay" />

      {/* Cursor glow */}
      <motion.div
        animate={{ x: cursorPos.x - 150, y: cursorPos.y - 150 }}
        transition={{ type: "spring", damping: 30, stiffness: 200 }}
        style={{
          position: "fixed",
          width: 300, height: 300,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(255,107,53,0.07) 0%, transparent 70%)",
          pointerEvents: "none",
          zIndex: 998,
        }}
      />

      {/* NAV */}
      <nav style={{
        position: "fixed",
        top: 0, left: 0, right: 0,
        zIndex: 100,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        borderBottom: "1px solid rgba(255,255,255,0.04)",
        backdropFilter: "blur(20px)",
        background: "rgba(6,6,8,0.8)",
        padding: "20px 48px",
      }} className="nav-pad">
        <span style={{ fontFamily: "'Bebas Neue', cursive", fontSize: 22, letterSpacing: "0.1em", color: "#FF6B35" }}>
          HACKER
        </span>
        <div style={{ display: "flex", gap: 32 }} className="nav-links">
          {NAV_LINKS.map((l) => (
            <a key={l} href={`#${l.toLowerCase()}`} className="nav-link">{l}</a>
          ))}
        </div>
        <a href="https://wa.me/2347070553083" target="_blank" rel="noreferrer" className="btn-primary" style={{ padding: "10px 20px" }}>
          Hire Me
        </a>
      </nav>

      {/* HERO */}
      <motion.section
        ref={heroRef}
        style={{ opacity: heroOpacity, y: heroY }}
        id="about"
      >
        <div style={{
          minHeight: "100vh",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          padding: "120px 48px 80px",
          maxWidth: 1100,
          margin: "0 auto",
          position: "relative",
        }} className="hero-pad">

          {/* BG ghost text */}
          <div style={{
            position: "absolute",
            top: "50%", right: -40,
            transform: "translateY(-50%)",
            fontFamily: "'Bebas Neue', cursive",
            fontSize: "clamp(120px, 18vw, 240px)",
            color: "rgba(255,255,255,0.025)",
            lineHeight: 1,
            userSelect: "none",
            pointerEvents: "none",
            letterSpacing: "-0.02em",
          }}>
            DESIGN
          </div>

          <motion.div variants={stagger} initial="hidden" animate="show">
            <motion.div variants={fadeUp} className="section-label">
              Available for projects · Lagos, Nigeria
            </motion.div>

            <motion.h1 variants={fadeUp} style={{
              fontFamily: "'Bebas Neue', cursive",
              fontSize: "clamp(64px, 11vw, 144px)",
              lineHeight: 0.9,
              letterSpacing: "-0.01em",
              marginBottom: 32,
            }}>
              <span style={{ display: "block" }}>Web</span>
              <span style={{ display: "block", color: "#FF6B35" }} className="glow-text">Designer</span>
              <span style={{
                display: "block",
                fontStyle: "italic",
                fontFamily: "'DM Sans', sans-serif",
                fontWeight: 300,
                fontSize: "clamp(20px, 4vw, 42px)",
                color: "#666",
                marginTop: 8,
              }}>& Brand Builder</span>
            </motion.h1>

            {/* Companies badge */}
            <motion.div variants={fadeUp} style={{
              display: "inline-flex",
              alignItems: "center",
              gap: 12,
              border: "1px solid rgba(255,255,255,0.08)",
              borderRadius: 2,
              padding: "10px 18px",
              marginBottom: 28,
              background: "rgba(255,255,255,0.02)",
            }}>
              <span style={{ fontSize: 11, letterSpacing: "0.18em", textTransform: "uppercase", color: "#555" }}>Worked with</span>
              <span style={{ width: 1, height: 14, background: "rgba(255,255,255,0.1)" }} />
              <span style={{ fontSize: 13, color: "#E8E4DC", fontWeight: 500 }}>X Perfumes</span>
              <span style={{ color: "#333" }}>·</span>
              <span style={{ fontSize: 13, color: "#E8E4DC", fontWeight: 500 }}>Tiglo Properties</span>
            </motion.div>

            <motion.p variants={fadeUp} style={{
              maxWidth: 480, color: "#888",
              lineHeight: 1.75, marginBottom: 40, fontSize: 16,
            }}>
              I help local businesses in Lagos attract more customers through clean, modern websites — mobile-first design with conversion built in.
            </motion.p>

            <motion.div variants={fadeUp} style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
              <a href="#projects" className="btn-primary">View Projects →</a>
              <a href="https://wa.me/2347070553083" target="_blank" rel="noreferrer" className="btn-ghost">💬 WhatsApp</a>
            </motion.div>
          </motion.div>

          {/* Scroll hint */}
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ repeat: Infinity, duration: 2 }}
            style={{
              position: "absolute",
              bottom: 40, left: 48,
              display: "flex",
              alignItems: "center",
              gap: 10,
              color: "#444",
              fontSize: 12,
              letterSpacing: "0.15em",
              textTransform: "uppercase",
            }}>
            <span style={{ width: 1, height: 40, background: "linear-gradient(to bottom, transparent, #444)" }} />
            Scroll
          </motion.div>
        </div>
      </motion.section>

      {/* STATS BAR */}
      <section style={{
        borderTop: "1px solid rgba(255,255,255,0.06)",
        borderBottom: "1px solid rgba(255,255,255,0.06)",
        padding: "48px",
      }} className="section-pad">
        <div style={{
          maxWidth: 1100, margin: "0 auto",
          display: "grid",
          gridTemplateColumns: "repeat(4, 1fr)",
          gap: 32,
        }} className="grid-4">
          {ACHIEVEMENTS.map((a, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              style={{ textAlign: "center" }}
            >
              <div className="stat-num">{a.num}</div>
              <div style={{ color: "#555", fontSize: 13, marginTop: 6, lineHeight: 1.5 }}>{a.label}</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* SKILLS */}
      <section id="skills" style={{ padding: "100px 48px", maxWidth: 1100, margin: "0 auto" }} className="section-pad">
        <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}>
          <div className="section-label">What I Do</div>
          <h2 style={{
            fontFamily: "'Bebas Neue', cursive",
            fontSize: "clamp(40px, 6vw, 72px)",
            letterSpacing: "0.02em",
            marginBottom: 48,
          }}>Services</h2>
        </motion.div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 1 }} className="grid-3">
          {SKILLS.map((s, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
            >
              <div className="skill-card">
                <div style={{ fontSize: 28, marginBottom: 20, color: "#FF6B35", fontFamily: "monospace" }}>{s.icon}</div>
                <div style={{ fontSize: 11, letterSpacing: "0.2em", textTransform: "uppercase", color: "#444", marginBottom: 8 }}>{s.tag}</div>
                <h3 style={{ fontSize: 20, fontWeight: 500, marginBottom: 12, color: "#E8E4DC" }}>{s.title}</h3>
                <p style={{ color: "#666", fontSize: 14, lineHeight: 1.7 }}>{s.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* PROJECTS */}
      <section id="projects" style={{ padding: "100px 48px", borderTop: "1px solid rgba(255,255,255,0.04)" }} className="section-pad">
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}>
            <div className="section-label">Portfolio</div>
            <h2 style={{
              fontFamily: "'Bebas Neue', cursive",
              fontSize: "clamp(40px, 6vw, 72px)",
              letterSpacing: "0.02em",
              marginBottom: 48,
            }}>Projects</h2>
          </motion.div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 1 }} className="grid-2">
            {PROJECTS.map((p, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
                whileHover={{ y: -4 }}
              >
                <div className="project-card">
                  <div style={{
                    fontFamily: "'Bebas Neue', cursive",
                    fontSize: 72,
                    color: "rgba(255,255,255,0.04)",
                    lineHeight: 1,
                    marginBottom: -16,
                  }}>{p.id}</div>

                  <div style={{ width: 40, height: 3, background: p.color, marginBottom: 20, borderRadius: 1 }} />

                  <div style={{ fontSize: 12, letterSpacing: "0.15em", textTransform: "uppercase", color: "#555", marginBottom: 8 }}>{p.subtitle}</div>
                  <h3 style={{
                    fontFamily: "'Bebas Neue', cursive",
                    fontSize: 32, letterSpacing: "0.04em",
                    color: "#E8E4DC", marginBottom: 16,
                  }}>{p.title}</h3>
                  <p style={{ color: "#666", fontSize: 14, lineHeight: 1.75, marginBottom: 24 }}>{p.desc}</p>

                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                    {p.tags.map((t) => (
                      <span key={t} style={{
                        fontSize: 11,
                        letterSpacing: "0.12em",
                        textTransform: "uppercase",
                        color: "#555",
                        border: "1px solid rgba(255,255,255,0.08)",
                        padding: "4px 10px",
                        borderRadius: 1,
                      }}>{t}</span>
                    ))}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CONTACT */}
      <section id="contact" style={{
        padding: "100px 48px",
        borderTop: "1px solid rgba(255,255,255,0.04)",
        position: "relative",
        overflow: "hidden",
      }} className="section-pad">
        <div style={{
          position: "absolute",
          bottom: -20, left: "50%",
          transform: "translateX(-50%)",
          fontFamily: "'Bebas Neue', cursive",
          fontSize: "clamp(80px, 15vw, 200px)",
          color: "rgba(255,255,255,0.015)",
          whiteSpace: "nowrap",
          pointerEvents: "none",
          userSelect: "none",
        }}>LET'S TALK</div>

        <div style={{ maxWidth: 680, margin: "0 auto", textAlign: "center", position: "relative" }}>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <div className="section-label" style={{ justifyContent: "center" }}>Open to Work</div>
            <h2 style={{
              fontFamily: "'Bebas Neue', cursive",
              fontSize: "clamp(48px, 8vw, 96px)",
              lineHeight: 0.95,
              letterSpacing: "0.02em",
              marginBottom: 24,
            }}>
              Let's Build<br />
              <span style={{ color: "#FF6B35" }}>Together</span>
            </h2>
            <p style={{ color: "#666", fontSize: 16, lineHeight: 1.75, maxWidth: 460, margin: "0 auto 40px" }}>
              Based in Lagos and ready to help your business stand out online. Reach out — I respond fast.
            </p>

            <div style={{ display: "flex", gap: 16, justifyContent: "center", flexWrap: "wrap" }}>
              <a href="https://wa.me/2347070553083" target="_blank" rel="noreferrer" className="btn-primary">
                💬 Chat on WhatsApp
              </a>
              <a href="mailto:joshuabankole1509@gmail.com" className="btn-ghost">
                Send Email
              </a>
            </div>
          </motion.div>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{
        borderTop: "1px solid rgba(255,255,255,0.04)",
        padding: "28px 48px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        color: "#333",
        fontSize: 12,
        letterSpacing: "0.1em",
      }} className="footer-pad">
        <span style={{ fontFamily: "'Bebas Neue', cursive", color: "#FF6B35", fontSize: 16 }}>HACKER</span>
        <span>© 2026 · Built with passion in Lagos</span>
        <span>Web Designer</span>
      </footer>
    </div>
  );
}
